document.getElementById('form-login').addEventListener('submit', async (event) => {
    event.preventDefault(); // Evita o comportamento padrão do formulário

    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;

    try {
        const response = await fetch('http://localhost:2000/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, senha })
        });

        const result = await response.json();
        if (response.ok) {
            alert(`Bem-vindo, ${result.nome}!`);
            // Redirecione para a página principal ou painel
            window.location.href = './pages/home.html'; // Ajuste conforme necessário
        } else {
            alert(result.error);
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao tentar fazer login. Tente novamente.');
    }
});
