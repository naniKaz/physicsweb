
    // Função para carregar todas as videoaulas
    async function carregarVideoaulas() {
        try {
            const response = await fetch('http://localhost:2000/videoaulas');
            const videoaulas = await response.json();

            if (response.ok) {
                const contentDiv = document.querySelector('.content');
                videoaulas.forEach(video => {
                    // Cria um cartão para cada videoaula
                    const card = document.createElement('div');
                    card.classList.add('video-card');
                    card.innerHTML = `
                        <h3>${video.titulo}</h3>
                        <p>${video.descricao}</p>
                        <a href="${video.url}" target="_blank">Assistir agora</a>
                    `;
                    contentDiv.appendChild(card);
                });
            } else {
                alert(videoaulas.error || 'Erro ao carregar videoaulas.');
            }
        } catch (error) {
            console.error('Erro:', error);
            alert('Erro ao carregar videoaulas.');
        }
    }

    // Chama a função ao carregar a página
    document.addEventListener('DOMContentLoaded', carregarVideoaulas);