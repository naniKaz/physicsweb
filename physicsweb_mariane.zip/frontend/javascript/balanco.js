// Dados da tabela (transcrevendo da imagem)
const balanco = [
    { ano: 1998, mecanica: 6, eletromagnetismo: 1, termologia: 1, optica: 1, ondulatoria: 0, hidrostatica: 0, fmc: 1, energias: 4, soma: 14 },
    { ano: 1999, mecanica: 1, eletromagnetismo: 2, termologia: 3, optica: 0, ondulatoria: 0, hidrostatica: 0, fmc: 0, energias: 7, soma: 13 },
    { ano: 2000, mecanica: 1, eletromagnetismo: 0, termologia: 1, optica: 0, ondulatoria: 0, hidrostatica: 0, fmc: 0, energias: 4, soma: 6 },
    { ano: 2001, mecanica: 0, eletromagnetismo: 2, termologia: 1, optica: 0, ondulatoria: 0, hidrostatica: 0, fmc: 0, energias: 1, soma: 4 },
    { ano: 2002, mecanica: 1, eletromagnetismo: 0, termologia: 0, optica: 0, ondulatoria: 0, hidrostatica: 0, fmc: 0, energias: 4, soma: 5 },
    { ano: 2003, mecanica: 5, eletromagnetismo: 0, termologia: 0, optica: 0, ondulatoria: 0, hidrostatica: 0, fmc: 0, energias: 5, soma: 10 },
    { ano: 2004, mecanica: 1, eletromagnetismo: 0, termologia: 0, optica: 0, ondulatoria: 0, hidrostatica: 0, fmc: 0, energias: 7, soma: 9 },
    { ano: 2005, mecanica: 3, eletromagnetismo: 1, termologia: 0, optica: 0, ondulatoria: 0, hidrostatica: 0, fmc: 0, energias: 2, soma: 6 },
    { ano: 2006, mecanica: 3, eletromagnetismo: 0, termologia: 2, optica: 0, ondulatoria: 0, hidrostatica: 0, fmc: 0, energias: 4, soma: 10 },
    { ano: 2007, mecanica: 0, eletromagnetismo: 0, termologia: 0, optica: 0, ondulatoria: 0, hidrostatica: 1, fmc: 0, energias: 7, soma: 9 },
    { ano: 2008, mecanica: 1, eletromagnetismo: 0, termologia: 0, optica: 0, ondulatoria: 0, hidrostatica: 0, fmc: 0, energias: 9, soma: 12 },
    { ano: 2009, mecanica: 3, eletromagnetismo: 4, termologia: 4, optica: 1, ondulatoria: 2, hidrostatica: 0, fmc: 0, energias: 0, soma: 14 },
    { ano: 2010, mecanica: 1, eletromagnetismo: 6, termologia: 4, optica: 1, ondulatoria: 1, hidrostatica: 0, fmc: 0, energias: 0, soma: 13 },
    { ano: 2011, mecanica: 5, eletromagnetismo: 3, termologia: 1, optica: 1, ondulatoria: 3, hidrostatica: 0, fmc: 0, energias: 0, soma: 13 },
    { ano: 2012, mecanica: 4, eletromagnetismo: 6, termologia: 1, optica: 3, ondulatoria: 1, hidrostatica: 0, fmc: 0, energias: 0, soma: 15 },
    { ano: 2013, mecanica: 4, eletromagnetismo: 6, termologia: 2, optica: 3, ondulatoria: 2, hidrostatica: 0, fmc: 0, energias: 1, soma: 16 },
    { ano: 2014, mecanica: 5, eletromagnetismo: 2, termologia: 1, optica: 6, ondulatoria: 1, hidrostatica: 0, fmc: 0, energias: 0, soma: 15 },
    { ano: 2015, mecanica: 5, eletromagnetismo: 3, termologia: 3, optica: 1, ondulatoria: 4, hidrostatica: 0, fmc: 0, energias: 0, soma: 16 },
    { ano: 2016, mecanica: 5, eletromagnetismo: 3, termologia: 3, optica: 0, ondulatoria: 4, hidrostatica: 0, fmc: 0, energias: 0, soma: 15 },
    { ano: 2017, mecanica: 4, eletromagnetismo: 1, termologia: 3, optica: 0, ondulatoria: 3, hidrostatica: 0, fmc: 1, energias: 1, soma: 16 },
    { ano: 2018, mecanica: 5, eletromagnetismo: 5, termologia: 1, optica: 2, ondulatoria: 1, hidrostatica: 0, fmc: 0, energias: 1, soma: 15 },
    { ano: 2019, mecanica: 6, eletromagnetismo: 2, termologia: 3, optica: 3, ondulatoria: 3, hidrostatica: 0, fmc: 0, energias: 1, soma: 18 },
    { ano: 2020, mecanica: 4, eletromagnetismo: 4, termologia: 3, optica: 2, ondulatoria: 2, hidrostatica: 2, fmc: 0, energias: 1, soma: 18 },
    { ano: 2021, mecanica: 4, eletromagnetismo: 6, termologia: 3, optica: 1, ondulatoria: 1, hidrostatica: 0, fmc: 0, energias: 1, soma: 16 },
    { ano: 2022, mecanica: 3, eletromagnetismo: 7, termologia: 1, optica: 1, ondulatoria: 1, hidrostatica: 0, fmc: 0, energias: 1, soma: 15 },
    { ano: 2023, mecanica: 4, eletromagnetismo: 3, termologia: 4, optica: 1, ondulatoria: 3, hidrostatica: 1, fmc: 0, energias: 1, soma: 17 }
];

// Preenchendo a tabela
const tabelaBody = document.querySelector('#balanco-tabela tbody');
balanco.forEach(item => {
    const row = `
        <tr>
            <td>${item.ano}</td>
            <td>${item.mecanica}</td>
            <td>${item.eletromagnetismo}</td>
            <td>${item.termologia}</td>
            <td>${item.optica}</td>
            <td>${item.ondulatoria}</td>
            <td>${item.hidrostatica}</td>
            <td>${item.fmc}</td>
            <td>${item.energias}</td>
            <td>${item.soma}</td>
        </tr>
    `;
    tabelaBody.insertAdjacentHTML('beforeend', row);
});
