async function carregarQuestoes() {
    try {
        const response = await fetch('http://localhost:2000/questoes');
        const questoes = await response.json();

        if (response.ok) {
            const contentDiv = document.querySelector('.content');
            questoes.forEach(questao => {
                // Cria um card para cada questão
                const card = document.createElement('div');
                card.classList.add('question-card');
                card.innerHTML = `
                    <div class="question" onclick="this.nextElementSibling.classList.toggle('show')">
                        ${questao.pergunta}
                    </div>
                    <div class="answer">
                        ${questao.gabarito}
                    </div>
                `;
                contentDiv.appendChild(card);
            });
        } else {
            alert(questoes.error || 'Erro ao carregar questões.');
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao carregar questões.');
    }
}

document.addEventListener('DOMContentLoaded', carregarQuestoes);