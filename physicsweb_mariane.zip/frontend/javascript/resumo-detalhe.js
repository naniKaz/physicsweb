
    // Função para capturar o ID da categoria na URL
    function getCategoriaId() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('id');
    }

    // Função para carregar o resumo da categoria
    async function carregarResumo() {
        const id_cat = getCategoriaId();

        if (!id_cat) {
            alert('ID da categoria não fornecido!');
            return;
        }

        try {
            const response = await fetch(`http://localhost:2000/resumo/${id_cat}`);
            const resumo = await response.json();

            if (response.ok) {
                // Exibe o resumo na página
                const contentDiv = document.querySelector('.content');
                contentDiv.innerHTML = `
                    <h1>${resumo.titulo}</h1>
                    ${resumo.conteudo}
                    <button onclick="window.location.href='./resumos.html'">Voltar</button>
                `;
            } else {
                alert(resumo.error || 'Erro ao carregar o resumo.');
            }
        } catch (error) {
            console.error('Erro:', error);
            alert('Erro ao carregar o resumo.');
        }
    }

    // Chama a função ao carregar a página
    document.addEventListener('DOMContentLoaded', carregarResumo);