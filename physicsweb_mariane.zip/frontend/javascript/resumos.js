
    // Função para buscar categorias e exibir no frontend
    async function carregarCategorias() {
        try {
            const response = await fetch('http://localhost:2000/categorias');
            const categorias = await response.json();

            if (response.ok) {
                const contentDiv = document.querySelector('.content');
                categorias.forEach(categoria => {
                    // Cria um botão para cada categoria
                    const button = document.createElement('button');
                    button.classList.add('topic');
                    button.textContent = categoria.nome;
                    button.addEventListener('click', () => {
                        window.location.href = `resumo_detalhe.html?id=${categoria.id}`;
                    });
                    contentDiv.appendChild(button);
                });
            } else {
                alert('Erro ao carregar categorias.');
            }
        } catch (error) {
            console.error('Erro:', error);
            alert('Erro ao carregar categorias.');
        }
    }

    // Chama a função ao carregar a página
    document.addEventListener('DOMContentLoaded', carregarCategorias);