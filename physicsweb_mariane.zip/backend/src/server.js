import express from 'express';
import app from './routes/router.js';
import cors from 'cors'; // Importa o pacote CORS

const server = express();

server.use(express.json());
server.use(express.urlencoded({extended:true}));
server.use(cors());

server.get('/ping',(req,res)=>res.json({pong:true}));

server.use('/', app);

server.listen(2000, ()=>console.log("Servidor rodando!"));