import express from 'express';
import db from '../db/db.js';

const app = express.Router();

// Rota de cadastro
app.post('/cadastro', async (req, res) => {
    const { nome, email, senha } = req.body;

    // Validação simples
    if (!nome || !email || !senha) {
        return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }

    try {
        // Verifica se o e-mail já está cadastrado
        const [usuarioExistente] = await db.query('SELECT * FROM usuarios WHERE email = ?', [email]);
        if (usuarioExistente.length > 0) {
            return res.status(400).json({ error: 'E-mail já cadastrado' });
        }

        // Insere o novo usuário no banco
        const tipo = 1; // Tipo padrão
        const query = 'INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, ?, ?)';
        await db.query(query, [nome, email, senha, tipo]);

        res.status(201).json({ message: 'Usuário cadastrado com sucesso!' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erro ao cadastrar o usuário' });
    }
});

// Rota de login
app.post('/login', async (req, res) => {
    const { email, senha } = req.body;

    // Validação simples
    if (!email || !senha) {
        return res.status(400).json({ error: 'Email e senha são obrigatórios' });
    }

    try {
        // Verifica se o usuário existe
        const [rows] = await db.query('SELECT * FROM usuarios WHERE email = ? AND senha = ?', [email, senha]);
        if (rows.length === 0) {
            return res.status(401).json({ error: 'Email ou senha incorretos' });
        }

        // Retorna os dados do usuário (sem expor a senha)
        const usuario = rows[0];
        const { id, nome, tipo } = usuario;
        res.status(200).json({ id, nome, tipo });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erro ao realizar login' });
    }
});

// Rota para listar categorias
app.get('/categorias', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT id, nome FROM categorias WHERE nome != "Enem"');
        res.status(200).json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erro ao buscar categorias' });
    }
});

// Rota para buscar o resumo correspondente a uma categoria
app.get('/resumo/:id_cat', async (req, res) => {
    const { id_cat } = req.params;

    try {
        const [rows] = await db.query('SELECT * FROM resumos WHERE id_cat = ?', [id_cat]);

        if (rows.length === 0) {
            return res.status(404).json({ error: 'Resumo não encontrado para esta categoria.' });
        }

        res.status(200).json(rows[0]); // Retorna apenas o primeiro resumo encontrado
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erro ao buscar o resumo.' });
    }
});

// Rota para buscar todas as videoaulas
app.get('/videoaulas', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM videoaulas');

        if (rows.length === 0) {
            return res.status(404).json({ error: 'Nenhuma videoaula encontrada.' });
        }

        res.status(200).json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erro ao buscar videoaulas.' });
    }
});

// Rota para buscar todas as questões
app.get('/questoes', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM questoes');
        if (rows.length === 0) {
            return res.status(404).json({ error: 'Nenhuma questão encontrada.' });
        }
        res.status(200).json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erro ao buscar questões.' });
    }
});

// Rota para buscar todas as questões do enem
app.get('/questoes/:id', async (req, res) => {
    const {id} = req.params;
    try {
        const [rows] = await db.query('SELECT * FROM questoes WHERE id_cat = ?', [id]);
        if (rows.length === 0) {
            return res.status(404).json({ error: 'Nenhuma questão encontrada.' });
        }
        res.status(200).json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erro ao buscar questões.' });
    }
});

export default app;